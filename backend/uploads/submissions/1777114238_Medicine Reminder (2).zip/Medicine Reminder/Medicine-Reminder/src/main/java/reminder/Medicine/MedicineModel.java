package reminder.Medicine;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class MedicineModel {
    private static int counter = 1;

    private int id;
    private String name;
    private String type;
    private String dosage;
    private List<LocalTime> times;
    private String frequency;
    private LocalDate startDate;
    private int durationDays;
    private int stockQuantity;
    private String notes;
    private List<String> takenHistory;

    public MedicineModel() {
        this.id = counter++;
        this.times = new ArrayList<>();
        this.takenHistory = new ArrayList<>();
    }

    public MedicineModel(String name, String type, String dosage, List<LocalTime> times,
                         String frequency, LocalDate startDate, int durationDays,
                         int stockQuantity, String notes) {
        this();
        this.name = name;
        this.type = type;
        this.dosage = dosage;
        this.times = times;
        this.frequency = frequency;
        this.startDate = startDate;
        this.durationDays = durationDays;
        this.stockQuantity = stockQuantity;
        this.notes = notes;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getDosage() { return dosage; }
    public void setDosage(String dosage) { this.dosage = dosage; }

    public List<LocalTime> getTimes() { return times; }
    public void setTimes(List<LocalTime> times) { this.times = times; }

    public String getFrequency() { return frequency; }
    public void setFrequency(String frequency) { this.frequency = frequency; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public int getDurationDays() { return durationDays; }
    public void setDurationDays(int durationDays) { this.durationDays = durationDays; }

    public int getStockQuantity() { return stockQuantity; }
    public void setStockQuantity(int stockQuantity) { this.stockQuantity = stockQuantity; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public List<String> getTakenHistory() { return takenHistory; }
    public void setTakenHistory(List<String> takenHistory) { this.takenHistory = takenHistory; }

    public boolean isActive() {
        LocalDate endDate = startDate.plusDays(durationDays);
        LocalDate today = LocalDate.now();
        return !today.isBefore(startDate) && !today.isAfter(endDate);
    }

    public LocalDate getEndDate() {
        return startDate.plusDays(durationDays);
    }

    public void markAsTaken() {
        stockQuantity--;
        takenHistory.add(LocalDate.now() + " " + LocalTime.now());
    }
}
