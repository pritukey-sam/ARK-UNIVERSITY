package reminder.Medicine;

import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class MedicineService {
    private List<MedicineModel> medicines = new ArrayList<>();

    public List<MedicineModel> getAllMedicines() {
        return medicines;
    }

    public List<MedicineModel> getActiveMedicines() {
        return medicines.stream()
                .filter(MedicineModel::isActive)
                .collect(Collectors.toList());
    }

    public void addMedicine(MedicineModel medicine) {
        medicines.add(medicine);
    }

    public void deleteMedicine(int id) {
        medicines.removeIf(m -> m.getId() == id);
    }

    public MedicineModel getMedicineById(int id) {
        return medicines.stream()
                .filter(m -> m.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<MedicineModel> getTodaySchedule() {
        LocalDate today = LocalDate.now();
        return medicines.stream()
                .filter(MedicineModel::isActive)
                .filter(m -> !m.getStartDate().isAfter(today))
                .collect(Collectors.toList());
    }

    public List<Map<String, Object>> getUpcomingReminders() {
        List<Map<String, Object>> reminders = new ArrayList<>();
        LocalTime now = LocalTime.now();
        LocalTime nextHour = now.plusHours(2);

        for (MedicineModel med : getActiveMedicines()) {
            for (LocalTime time : med.getTimes()) {
                if (time.isAfter(now) && time.isBefore(nextHour)) {
                    Map<String, Object> reminder = new HashMap<>();
                    reminder.put("medicine", med);
                    reminder.put("time", time);
                    reminders.add(reminder);
                }
            }
        }
        return reminders;
    }

    public void markMedicineAsTaken(int id) {
        MedicineModel med = getMedicineById(id);
        if (med != null) {
            med.markAsTaken();
        }
    }

    public int getTotalActiveMedicines() {
        return (int) medicines.stream().filter(MedicineModel::isActive).count();
    }

    public int getLowStockCount() {
        return (int) medicines.stream()
                .filter(m -> m.getStockQuantity() < 5)
                .count();
    }
}
