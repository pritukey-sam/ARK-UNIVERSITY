package reminder.Medicine;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Controller
public class MedicineController {

    @Autowired
    private MedicineService medicineService;

    @GetMapping("/")
    public String dashboard(Model model) {
        model.addAttribute("medicines", medicineService.getActiveMedicines());
        model.addAttribute("todaySchedule", medicineService.getTodaySchedule());
        model.addAttribute("totalActive", medicineService.getTotalActiveMedicines());
        model.addAttribute("lowStock", medicineService.getLowStockCount());
        model.addAttribute("upcomingReminders", medicineService.getUpcomingReminders());
        return "dashboard";
    }

    @GetMapping("/add")
    public String showAddForm() {
        return "add-medicine";
    }

    @PostMapping("/add")
    public String addMedicine(@RequestParam String name,
                              @RequestParam String type,
                              @RequestParam String dosage,
                              @RequestParam String frequency,
                              @RequestParam String time1,
                              @RequestParam(required = false) String time2,
                              @RequestParam(required = false) String time3,
                              @RequestParam String startDate,
                              @RequestParam int duration,
                              @RequestParam int stock,
                              @RequestParam(required = false) String notes) {

        List<LocalTime> times = new ArrayList<>();
        times.add(LocalTime.parse(time1));
        if (time2 != null && !time2.isEmpty()) times.add(LocalTime.parse(time2));
        if (time3 != null && !time3.isEmpty()) times.add(LocalTime.parse(time3));

        MedicineModel medicine = new MedicineModel(
                name, type, dosage, times, frequency,
                LocalDate.parse(startDate), duration, stock,
                notes != null ? notes : ""
        );

        medicineService.addMedicine(medicine);
        return "redirect:/?success=true";
    }

    @PostMapping("/delete/{id}")
    public String deleteMedicine(@PathVariable int id) {
        medicineService.deleteMedicine(id);
        return "redirect:/";
    }

    @PostMapping("/mark-taken/{id}")
    public String markAsTaken(@PathVariable int id) {
        medicineService.markMedicineAsTaken(id);
        return "redirect:/";
    }

    @GetMapping("/history/{id}")
    public String viewHistory(@PathVariable int id, Model model) {
        MedicineModel medicine = medicineService.getMedicineById(id);
        model.addAttribute("medicine", medicine);
        return "history";
    }

    @GetMapping("/check-reminders")
    @ResponseBody
    public List<MedicineModel> checkReminders() {
        LocalTime now = LocalTime.now();

        List<MedicineModel> dueNow = new ArrayList<>();
        for (MedicineModel med : medicineService.getActiveMedicines()) {
            for (LocalTime time : med.getTimes()) {
                if (time.getHour() == now.getHour() &&
                        time.getMinute() == now.getMinute()) {
                    dueNow.add(med);
                    break;
                }
            }
        }
        return dueNow;
    }
}