//package Level3.Task3;
//
//import javafx.application.Application;
//import javafx.geometry.Insets;
//import javafx.geometry.Pos;
//import javafx.scene.Scene;
//import javafx.scene.control.*;
//import javafx.scene.layout.*;
//import javafx.stage.Stage;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//
//public class TodoListApp extends Application {
//
//    private ListView<String> taskListView;
//    private ObservableList<String> tasks;
//    private TextField taskInput;
//
//    public static void main(String[] args) {
//        launch(args);
//    }
//
//    @Override
//    public void start(Stage primaryStage) {
//        primaryStage.setTitle("Todo List Application");
//
//        tasks = FXCollections.observableArrayList();
//
//        Label titleLabel = new Label("My Todo List");
//        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
//
//        taskInput = new TextField();
//        taskInput.setPromptText("Enter a new task...");
//        taskInput.setPrefHeight(40);
//
//        Button addButton = new Button("Add Task");
//        addButton.setPrefHeight(40);
//        addButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
//        addButton.setOnAction(e -> addTask());
//
//        taskInput.setOnAction(e -> addTask());
//
//        HBox inputBox = new HBox(10);
//        inputBox.getChildren().addAll(taskInput, addButton);
//        HBox.setHgrow(taskInput, Priority.ALWAYS);
//
//        taskListView = new ListView<>(tasks);
//        taskListView.setPrefHeight(300);
//
//        Button deleteButton = new Button("Delete Selected");
//        deleteButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");
//        deleteButton.setOnAction(e -> deleteTask());
//
//        Button clearButton = new Button("Clear All");
//        clearButton.setStyle("-fx-background-color: #ff9800; -fx-text-fill: white;");
//        clearButton.setOnAction(e -> clearAll());
//
//        HBox buttonBox = new HBox(10);
//        buttonBox.setAlignment(Pos.CENTER);
//        buttonBox.getChildren().addAll(deleteButton, clearButton);
//
//        VBox root = new VBox(15);
//        root.setPadding(new Insets(20));
//        root.getChildren().addAll(titleLabel, inputBox, taskListView, buttonBox);
//
//        Scene scene = new Scene(root, 400, 500);
//        primaryStage.setScene(scene);
//        primaryStage.show();
//    }
//
//    private void addTask() {
//        String task = taskInput.getText().trim();
//        if (!task.isEmpty()) {
//            tasks.add(task);
//            taskInput.clear();
//            showAlert("Success", "Task added successfully!", Alert.AlertType.INFORMATION);
//        } else {
//            showAlert("Error", "Please enter a task!", Alert.AlertType.ERROR);
//        }
//    }
//
//    private void deleteTask() {
//        int selectedIndex = taskListView.getSelectionModel().getSelectedIndex();
//        if (selectedIndex >= 0) {
//            tasks.remove(selectedIndex);
//            showAlert("Success", "Task deleted successfully!", Alert.AlertType.INFORMATION);
//        } else {
//            showAlert("Error", "Please select a task to delete!", Alert.AlertType.ERROR);
//        }
//    }
//
//    private void clearAll() {
//        if (!tasks.isEmpty()) {
//            Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
//            confirmation.setTitle("Confirmation");
//            confirmation.setHeaderText("Clear All Tasks");
//            confirmation.setContentText("Are you sure you want to delete all tasks?");
//
//            if (confirmation.showAndWait().get() == ButtonType.OK) {
//                tasks.clear();
//                showAlert("Success", "All tasks cleared!", Alert.AlertType.INFORMATION);
//            }
//        } else {
//            showAlert("Error", "No tasks to clear!", Alert.AlertType.ERROR);
//        }
//    }
//
//    private void showAlert(String title, String message, Alert.AlertType type) {
//        Alert alert = new Alert(type);
//        alert.setTitle(title);
//        alert.setHeaderText(null);
//        alert.setContentText(message);
//        alert.showAndWait();
//    }
//}
