package Level1;
import java.util.Scanner;

public class Task1 {

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("=== Temperature Converter ===");
            System.out.println();


            System.out.print("Enter the temperature value: ");
            double temperature = scanner.nextDouble();


            System.out.print("Enter the unit (C for Celsius, F for Fahrenheit): ");
            char unit = scanner.next().toUpperCase().charAt(0);


            if (unit == 'C') {

                double fahrenheit = (temperature * 9/5) + 32;
                System.out.println();
                System.out.printf("%.2f°C = %.2f°F%n", temperature, fahrenheit);
            }
            else if (unit == 'F') {

                double celsius = (temperature - 32) * 5/9;
                System.out.println();
                System.out.printf("%.2f°F = %.2f°C%n", temperature, celsius);
            }
            else {
                System.out.println();
                System.out.println("Invalid unit! Please enter C or F.");
            }

            scanner.close();
        }
    }


