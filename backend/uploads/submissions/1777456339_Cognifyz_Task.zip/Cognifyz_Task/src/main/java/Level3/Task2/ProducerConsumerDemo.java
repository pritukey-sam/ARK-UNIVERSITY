package Level3.Task2;

import java.util.LinkedList;
import java.util.Queue;

public class ProducerConsumerDemo {
    public static void main(String[] args) {
        System.out.println("=== Producer-Consumer Problem ===");
        System.out.println();

        SharedBuffer buffer = new SharedBuffer(5);

        Thread producer1 = new Thread(new Producer(buffer, "Producer-1"));
        Thread producer2 = new Thread(new Producer(buffer, "Producer-2"));
        Thread consumer1 = new Thread(new Consumer(buffer, "Consumer-1"));
        Thread consumer2 = new Thread(new Consumer(buffer, "Consumer-2"));

        producer1.start();
        producer2.start();
        consumer1.start();
        consumer2.start();

        try {
            Thread.sleep(5000);
            producer1.interrupt();
            producer2.interrupt();
            consumer1.interrupt();
            consumer2.interrupt();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class SharedBuffer {
    private Queue<Integer> queue;
    private int capacity;

    public SharedBuffer(int capacity) {
        this.queue = new LinkedList<>();
        this.capacity = capacity;
    }

    public synchronized void produce(int item, String producerName) throws InterruptedException {
        while (queue.size() == capacity) {
            System.out.println(producerName + " waiting - Buffer is full");
            wait();
        }

        queue.add(item);
        System.out.println(producerName + " produced: " + item +
                " | Buffer size: " + queue.size());

        notifyAll();
    }

    public synchronized int consume(String consumerName) throws InterruptedException {
        while (queue.isEmpty()) {
            System.out.println(consumerName + " waiting - Buffer is empty");
            wait();
        }

        int item = queue.poll();
        System.out.println(consumerName + " consumed: " + item +
                " | Buffer size: " + queue.size());

        notifyAll();
        return item;
    }
}

class Producer implements Runnable {
    private SharedBuffer buffer;
    private String name;
    private int counter = 1;

    public Producer(SharedBuffer buffer, String name) {
        this.buffer = buffer;
        this.name = name;
    }

    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                buffer.produce(counter++, name);
                Thread.sleep(500);
            }
        } catch (InterruptedException e) {
            System.out.println(name + " stopped");
        }
    }
}

class Consumer implements Runnable {
    private SharedBuffer buffer;
    private String name;

    public Consumer(SharedBuffer buffer, String name) {
        this.buffer = buffer;
        this.name = name;
    }

    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                buffer.consume(name);
                Thread.sleep(800);
            }
        } catch (InterruptedException e) {
            System.out.println(name + " stopped");
        }
    }
}
