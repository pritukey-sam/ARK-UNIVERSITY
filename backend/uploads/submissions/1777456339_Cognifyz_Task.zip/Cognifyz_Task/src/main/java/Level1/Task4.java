package Level1;

import java.util.Scanner;
import java.util.Random;

public class Task4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        System.out.println("=== Random Password Generator ===");
        System.out.println();

        System.out.print("Enter desired password length: ");
        int length = sc.nextInt();

        System.out.println();
        System.out.print("Include lowercase letters? (yes/no): ");
        String lowerChoice = sc.next();
        boolean includeLowercase = lowerChoice.equalsIgnoreCase("yes");

        System.out.print("Include uppercase letters? (yes/no): ");
        String upperChoice = sc.next();
        boolean includeUppercase = upperChoice.equalsIgnoreCase("yes");

        System.out.print("Include numbers? (yes/no): ");
        String numberChoice = sc.next();
        boolean includeNumbers = numberChoice.equalsIgnoreCase("yes");

        System.out.print("Include special characters? (yes/no): ");
        String specialChoice = sc.next();
        boolean includeSpecial = specialChoice.equalsIgnoreCase("yes");

        String lowercase = "abcdefghijklmnopqrstuvwxyz";
        String uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String numbers = "0123456789";
        String special = "!@#$%^&*()_+-=[]{}|;:,.<>?";

        String characterPool = "";

        if (includeLowercase) {
            characterPool += lowercase;
        }
        if (includeUppercase) {
            characterPool += uppercase;
        }
        if (includeNumbers) {
            characterPool += numbers;
        }
        if (includeSpecial) {
            characterPool += special;
        }

        if (characterPool.isEmpty()) {
            System.out.println();
            System.out.println("Error: You must select at least one character type!");
            sc.close();
            return;
        }

        String password = "";
        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(characterPool.length());
            password += characterPool.charAt(randomIndex);
        }

        System.out.println();
        System.out.println("--- Generated Password ---");
        System.out.println("Your password: " + password);
        System.out.println("Password length: " + password.length());
        System.out.println();
        System.out.println("Password includes:");
        if (includeLowercase) System.out.println("- Lowercase letters");
        if (includeUppercase) System.out.println("- Uppercase letters");
        if (includeNumbers) System.out.println("- Numbers");
        if (includeSpecial) System.out.println("- Special characters");

        sc.close();
    }
}
