package Level3.Task2;

import java.util.concurrent.locks.*;

public class ReentrantLockDemo {
    private static Lock lock = new ReentrantLock();
    private static int counter = 0;

    public static void main(String[] args) {
        System.out.println("=== ReentrantLock Demo ===");
        System.out.println();

        Thread[] threads = new Thread[5];

        for (int i = 0; i < 5; i++) {
            threads[i] = new Thread(new CounterTask("Thread-" + (i + 1)));
            threads[i].start();
        }

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println();
        System.out.println("Final Counter Value: " + counter);
    }

    static class CounterTask implements Runnable {
        private String name;

        public CounterTask(String name) {
            this.name = name;
        }

        @Override
        public void run() {
            for (int i = 0; i < 1000; i++) {
                lock.lock();
                try {
                    counter++;
                } finally {
                    lock.unlock();
                }
            }
            System.out.println(name + " completed 1000 increments");
        }
    }
}
