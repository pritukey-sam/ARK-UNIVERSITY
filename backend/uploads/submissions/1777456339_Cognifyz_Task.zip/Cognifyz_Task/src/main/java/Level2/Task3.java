package Level2;

import java.io.*;
import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== File Encryption/Decryption ===");
        System.out.println();

        System.out.println("Choose an option:");
        System.out.println("1. Encrypt a file");
        System.out.println("2. Decrypt a file");
        System.out.print("Enter your choice (1 or 2): ");
        int choice = sc.nextInt();
        sc.nextLine();

        System.out.println();
        System.out.print("Enter the input file name (with path if needed): ");
        String inputFile = sc.nextLine();

        System.out.print("Enter the output file name: ");
        String outputFile = sc.nextLine();

        System.out.print("Enter encryption key (a number): ");
        int key = sc.nextInt();

        if (choice == 1) {
            encryptFile(inputFile, outputFile, key);
        } else if (choice == 2) {
            decryptFile(inputFile, outputFile, key);
        } else {
            System.out.println("Invalid choice!");
        }

        sc.close();
    }

    static void encryptFile(String inputFile, String outputFile, int key) {
        try {
            FileReader fr = new FileReader(inputFile);
            BufferedReader br = new BufferedReader(fr);

            FileWriter fw = new FileWriter(outputFile);
            BufferedWriter bw = new BufferedWriter(fw);

            System.out.println();
            System.out.println("Encrypting file...");

            String line;
            while ((line = br.readLine()) != null) {
                String encryptedLine = encrypt(line, key);
                bw.write(encryptedLine);
                bw.newLine();
            }

            br.close();
            bw.close();

            System.out.println("Encryption successful!");
            System.out.println("Encrypted file saved as: " + outputFile);

        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found - " + inputFile);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    static void decryptFile(String inputFile, String outputFile, int key) {
        try {
            FileReader fr = new FileReader(inputFile);
            BufferedReader br = new BufferedReader(fr);

            FileWriter fw = new FileWriter(outputFile);
            BufferedWriter bw = new BufferedWriter(fw);

            System.out.println();
            System.out.println("Decrypting file...");

            String line;
            while ((line = br.readLine()) != null) {
                String decryptedLine = decrypt(line, key);
                bw.write(decryptedLine);
                bw.newLine();
            }

            br.close();
            bw.close();

            System.out.println("Decryption successful!");
            System.out.println("Decrypted file saved as: " + outputFile);

        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found - " + inputFile);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    static String encrypt(String text, int key) {
        String encrypted = "";

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);

            if (ch >= 'a' && ch <= 'z') {
                ch = (char) ((ch - 'a' + key) % 26 + 'a');
            } else if (ch >= 'A' && ch <= 'Z') {
                ch = (char) ((ch - 'A' + key) % 26 + 'A');
            } else if (ch >= '0' && ch <= '9') {
                ch = (char) ((ch - '0' + key) % 10 + '0');
            }

            encrypted += ch;
        }

        return encrypted;
    }

    static String decrypt(String text, int key) {
        String decrypted = "";

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);

            if (ch >= 'a' && ch <= 'z') {
                ch = (char) ((ch - 'a' - key + 26) % 26 + 'a');
            } else if (ch >= 'A' && ch <= 'Z') {
                ch = (char) ((ch - 'A' - key + 26) % 26 + 'A');
            } else if (ch >= '0' && ch <= '9') {
                ch = (char) ((ch - '0' - key + 10) % 10 + '0');
            }

            decrypted += ch;
        }

        return decrypted;
    }
}