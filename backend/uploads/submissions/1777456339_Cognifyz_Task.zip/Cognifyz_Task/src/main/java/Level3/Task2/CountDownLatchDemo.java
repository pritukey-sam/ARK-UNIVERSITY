package Level3.Task2;

import java.util.concurrent.*;

public class CountDownLatchDemo {
    public static void main(String[] args) {
        System.out.println("=== CountDownLatch Demo ===");
        System.out.println();

        int numWorkers = 3;
        CountDownLatch latch = new CountDownLatch(numWorkers);

        for (int i = 1; i <= numWorkers; i++) {
            Thread worker = new Thread(new Worker(latch, "Worker-" + i));
            worker.start();
        }

        try {
            System.out.println("Main thread waiting for all workers to complete...");
            latch.await();
            System.out.println();
            System.out.println("All workers completed! Main thread proceeding...");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class Worker implements Runnable {
    private CountDownLatch latch;
    private String name;

    public Worker(CountDownLatch latch, String name) {
        this.latch = latch;
        this.name = name;
    }

    @Override
    public void run() {
        try {
            System.out.println(name + " starting work...");
            Thread.sleep((long)(Math.random() * 3000));
            System.out.println(name + " completed work!");
            latch.countDown();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
