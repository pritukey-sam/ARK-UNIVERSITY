package Level1;

import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("---Welcome to Palindrome Checker---");
        System.out.println();


        System.out.print("Enter a word or phrase: ");
        String palin = sc.nextLine();


        String cleaned = palin.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();


        String rev = "";
        for (int i = cleaned.length() - 1; i >= 0; i--) {
            rev = rev + cleaned.charAt(i);
        }


        if (cleaned.equals(rev)) {
            System.out.println("\"" + palin + "\" is a PALINDROME!");
        } else {
            System.out.println("\"" + palin + "\" is NOT a palindrome.");
        }

        sc.close();
    }
}