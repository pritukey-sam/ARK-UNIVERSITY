package Level3.Task3;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.io.File;

public class SimpleFileManager extends JFrame {

    private JTree fileTree;
    private JTextArea fileDetails;

    public SimpleFileManager() {
        setTitle("Simple File Manager");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JSplitPane splitPane = new JSplitPane();

        File rootFile = new File(System.getProperty("user.home"));
        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode(rootFile);
        createTree(rootNode, rootFile);

        fileTree = new JTree(rootNode);
        fileTree.addTreeSelectionListener(e -> {
            DefaultMutableTreeNode selectedNode =
                    (DefaultMutableTreeNode) fileTree.getLastSelectedPathComponent();
            if (selectedNode != null) {
                File file = (File) selectedNode.getUserObject();
                displayFileInfo(file);
            }
        });

        JScrollPane treeScrollPane = new JScrollPane(fileTree);
        treeScrollPane.setPreferredSize(new Dimension(300, 600));

        fileDetails = new JTextArea();
        fileDetails.setEditable(false);
        fileDetails.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane detailsScrollPane = new JScrollPane(fileDetails);

        splitPane.setLeftComponent(treeScrollPane);
        splitPane.setRightComponent(detailsScrollPane);
        splitPane.setDividerLocation(300);

        add(splitPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        JLabel statusLabel = new JLabel("Ready");
        bottomPanel.add(statusLabel);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void createTree(DefaultMutableTreeNode node, File file) {
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File child : files) {
                    if (child.isDirectory()) {
                        DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(child);
                        node.add(childNode);
                    }
                }
            }
        }
    }

    private void displayFileInfo(File file) {
        StringBuilder info = new StringBuilder();
        info.append("Name: ").append(file.getName()).append("\n");
        info.append("Path: ").append(file.getAbsolutePath()).append("\n");
        info.append("Type: ").append(file.isDirectory() ? "Directory" : "File").append("\n");
        info.append("Size: ").append(file.length()).append(" bytes\n");
        info.append("Readable: ").append(file.canRead()).append("\n");
        info.append("Writable: ").append(file.canWrite()).append("\n");
        info.append("Hidden: ").append(file.isHidden()).append("\n");
        info.append("Last Modified: ").append(new java.util.Date(file.lastModified())).append("\n");

        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                info.append("\nContents (").append(files.length).append(" items):\n");
                for (File child : files) {
                    info.append("  - ").append(child.getName());
                    if (child.isDirectory()) {
                        info.append(" [DIR]");
                    }
                    info.append("\n");
                }
            }
        }

        fileDetails.setText(info.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SimpleFileManager());
    }
}
