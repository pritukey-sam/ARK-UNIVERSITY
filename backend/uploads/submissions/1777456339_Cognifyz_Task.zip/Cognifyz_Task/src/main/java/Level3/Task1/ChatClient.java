package Level3.Task1;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ChatClient {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 5000;

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private Scanner scanner;

    public ChatClient() {
        scanner = new Scanner(System.in);
    }

    public void start() {
        try {
            // Connect to server
            System.out.println("=== Chat Client ===");
            System.out.println("Connecting to server...");

            socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            System.out.println("Connected to server!");
            System.out.println();

            // Start thread to listen for incoming messages
            Thread listenerThread = new Thread(new IncomingMessageHandler());
            listenerThread.start();

            // Read and send messages
            String message;
            while (true) {
                message = scanner.nextLine();

                if (message.equalsIgnoreCase("exit")) {
                    out.println(message);
                    break;
                }

                out.println(message);
            }

        } catch (UnknownHostException e) {
            System.err.println("Unknown host: " + SERVER_ADDRESS);
        } catch (IOException e) {
            System.err.println("Error connecting to server: " + e.getMessage());
        } finally {
            disconnect();
        }
    }

    // Disconnect from server
    private void disconnect() {
        try {
            System.out.println("\nDisconnected from server.");

            if (scanner != null) {
                scanner.close();
            }
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            System.err.println("Error disconnecting: " + e.getMessage());
        }
    }

    // Thread to handle incoming messages from server
    class IncomingMessageHandler implements Runnable {
        @Override
        public void run() {
            try {
                String message;
                while ((message = in.readLine()) != null) {
                    System.out.println(message);
                }
            } catch (IOException e) {
                System.err.println("Connection lost.");
            }
        }
    }

    public static void main(String[] args) {
        ChatClient client = new ChatClient();
        client.start();
    }
}
