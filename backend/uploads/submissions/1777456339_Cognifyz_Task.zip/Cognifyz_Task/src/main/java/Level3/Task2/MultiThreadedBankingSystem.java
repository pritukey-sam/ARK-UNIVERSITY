package Level3.Task2;

import java.util.*;
import java.util.concurrent.*;

public class MultiThreadedBankingSystem {
    public static void main(String[] args) {
        System.out.println("=== Multi-threaded Banking System ===");
        System.out.println();

        BankAccount account = new BankAccount("ACC001", 1000.0);

        Thread t1 = new Thread(new Customer(account, "Alice", 200, true));
        Thread t2 = new Thread(new Customer(account, "Bob", 150, false));
        Thread t3 = new Thread(new Customer(account, "Charlie", 300, true));
        Thread t4 = new Thread(new Customer(account, "Diana", 100, false));
        Thread t5 = new Thread(new Customer(account, "Eve", 250, true));

        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();

        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
            t5.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println();
        System.out.println("=== Final Account Status ===");
        System.out.println("Account Number: " + account.getAccountNumber());
        System.out.println("Final Balance: $" + account.getBalance());
        System.out.println("Total Transactions: " + account.getTransactionCount());
    }
}

class BankAccount {
    private String accountNumber;
    private double balance;
    private int transactionCount;

    public BankAccount(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
        this.transactionCount = 0;
    }

    public synchronized void deposit(String customerName, double amount) {
        System.out.println("[" + Thread.currentThread().getName() + "] " +
                customerName + " attempting to deposit $" + amount);

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        balance += amount;
        transactionCount++;

        System.out.println("[" + Thread.currentThread().getName() + "] " +
                customerName + " deposited $" + amount +
                " | New Balance: $" + balance);
    }

    public synchronized boolean withdraw(String customerName, double amount) {
        System.out.println("[" + Thread.currentThread().getName() + "] " +
                customerName + " attempting to withdraw $" + amount);

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (balance >= amount) {
            balance -= amount;
            transactionCount++;
            System.out.println("[" + Thread.currentThread().getName() + "] " +
                    customerName + " withdrew $" + amount +
                    " | New Balance: $" + balance);
            return true;
        } else {
            System.out.println("[" + Thread.currentThread().getName() + "] " +
                    customerName + " withdrawal FAILED - Insufficient funds" +
                    " | Current Balance: $" + balance);
            return false;
        }
    }

    public synchronized double getBalance() {
        return balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public int getTransactionCount() {
        return transactionCount;
    }
}

class Customer implements Runnable {
    private BankAccount account;
    private String name;
    private double amount;
    private boolean isDeposit;

    public Customer(BankAccount account, String name, double amount, boolean isDeposit) {
        this.account = account;
        this.name = name;
        this.amount = amount;
        this.isDeposit = isDeposit;
    }

    @Override
    public void run() {
        if (isDeposit) {
            account.deposit(name, amount);
        } else {
            account.withdraw(name, amount);
        }
    }
}