package Level3.Task1;

import java.io.*;
import java.net.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ChatServer {
    private static final int PORT = 5000;
    private static Set<ClientHandler> clientHandlers = new HashSet<>();
    private static int clientCounter = 0;

    public static void main(String[] args) {
        System.out.println("=== Chat Server Started ===");
        System.out.println("Waiting for clients to connect...");
        System.out.println("Server running on port: " + PORT);
        System.out.println();

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket socket = serverSocket.accept();
                clientCounter++;

                ClientHandler clientHandler = new ClientHandler(socket, clientCounter);
                clientHandlers.add(clientHandler);

                Thread thread = new Thread(clientHandler);
                thread.start();
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    // Broadcast message to all clients
    public static void broadcastMessage(String message, ClientHandler sender) {
        for (ClientHandler client : clientHandlers) {
            client.sendMessage(message);
        }
    }

    // Remove client from active clients
    public static void removeClient(ClientHandler clientHandler) {
        clientHandlers.remove(clientHandler);
    }

    // Get current timestamp
    public static String getTimestamp() {
        return new SimpleDateFormat("HH:mm:ss").format(new Date());
    }
}

// Handler for each client connection
class ClientHandler implements Runnable {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private String username;
    private int clientId;

    public ClientHandler(Socket socket, int clientId) {
        this.socket = socket;
        this.clientId = clientId;
    }

    @Override
    public void run() {
        try {
            // Setup input and output streams
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // Get username from client
            out.println("Enter your username: ");
            username = in.readLine();

            if (username == null || username.trim().isEmpty()) {
                username = "User" + clientId;
            }

            System.out.println("[" + ChatServer.getTimestamp() + "] " + username + " connected");

            // Notify all clients about new user
            ChatServer.broadcastMessage(
                    "[" + ChatServer.getTimestamp() + "] " + username + " joined the chat!",
                    this
            );

            // Send welcome message to the new user
            out.println("Welcome to the chat, " + username + "!");
            out.println("Type your messages below. Type 'exit' to quit.");
            out.println("--------------------------------------------");

            // Listen for messages from client
            String message;
            while ((message = in.readLine()) != null) {
                if (message.equalsIgnoreCase("exit")) {
                    break;
                }

                if (!message.trim().isEmpty()) {
                    String formattedMessage = "[" + ChatServer.getTimestamp() + "] " +
                            username + ": " + message;
                    System.out.println(formattedMessage);
                    ChatServer.broadcastMessage(formattedMessage, this);
                }
            }

        } catch (IOException e) {
            System.err.println("Error with client " + username + ": " + e.getMessage());
        } finally {
            disconnect();
        }
    }

    // Send message to this client
    public void sendMessage(String message) {
        out.println(message);
    }

    // Disconnect client
    private void disconnect() {
        try {
            ChatServer.removeClient(this);

            if (username != null) {
                System.out.println("[" + ChatServer.getTimestamp() + "] " + username + " disconnected");
                ChatServer.broadcastMessage(
                        "[" + ChatServer.getTimestamp() + "] " + username + " left the chat.",
                        this
                );
            }

            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
}