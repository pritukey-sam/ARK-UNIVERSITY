package Level2;

import java.util.Scanner;

public class Task1 {
    static char[][] board = new char[3][3];
    static Scanner sc = new Scanner(System.in);
    static char currentPlayer = 'X';

    public static void main(String[] args) {
        boolean playAgain = true;
        int player1Wins = 0;
        int player2Wins = 0;
        int draws = 0;

        System.out.println("=== Tic-Tac-Toe Game ===");
        System.out.println();

        while (playAgain) {
            initializeBoard();
            currentPlayer = 'X';
            boolean gameWon = false;
            boolean gameDraw = false;

            System.out.println("Player 1: X");
            System.out.println("Player 2: O");
            System.out.println();

            while (!gameWon && !gameDraw) {
                displayBoard();
                playerMove();
                gameWon = checkWin();
                gameDraw = checkDraw();

                if (!gameWon && !gameDraw) {
                    switchPlayer();
                }
            }

            displayBoard();

            if (gameWon) {
                System.out.println();
                System.out.println("Player " + currentPlayer + " wins!");
                if (currentPlayer == 'X') {
                    player1Wins++;
                } else {
                    player2Wins++;
                }
            } else if (gameDraw) {
                System.out.println();
                System.out.println("It's a draw!");
                draws++;
            }

            System.out.println();
            System.out.println("--- Score Board ---");
            System.out.println("Player X wins: " + player1Wins);
            System.out.println("Player O wins: " + player2Wins);
            System.out.println("Draws: " + draws);
            System.out.println();

            System.out.print("Do you want to play again? (yes/no): ");
            String choice = sc.next();
            playAgain = choice.equalsIgnoreCase("yes");
            System.out.println();
        }

        System.out.println("Thanks for playing!");
        sc.close();
    }

    static void initializeBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = ' ';
            }
        }
    }

    static void displayBoard() {
        System.out.println();
        System.out.println("     1   2   3");
        System.out.println("   -------------");
        for (int i = 0; i < 3; i++) {
            System.out.print(" " + (i + 1) + " | ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j]);
                if (j < 2) {
                    System.out.print(" | ");
                }
            }
            System.out.println(" |");
            if (i < 2) {
                System.out.println("   -------------");
            }
        }
        System.out.println("   -------------");
        System.out.println();
    }

    static void playerMove() {
        int row, col;
        boolean validMove = false;

        while (!validMove) {
            System.out.println("Player " + currentPlayer + "'s turn");
            System.out.print("Enter row (1-3): ");
            row = sc.nextInt();
            System.out.print("Enter column (1-3): ");
            col = sc.nextInt();

            row--;
            col--;

            if (row >= 0 && row < 3 && col >= 0 && col < 3) {
                if (board[row][col] == ' ') {
                    board[row][col] = currentPlayer;
                    validMove = true;
                } else {
                    System.out.println("That position is already taken. Try again.");
                    System.out.println();
                }
            } else {
                System.out.println("Invalid position. Please enter numbers between 1 and 3.");
                System.out.println();
            }
        }
    }

    static void switchPlayer() {
        if (currentPlayer == 'X') {
            currentPlayer = 'O';
        } else {
            currentPlayer = 'X';
        }
    }

    static boolean checkWin() {
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == currentPlayer && board[i][1] == currentPlayer && board[i][2] == currentPlayer) {
                return true;
            }
        }

        for (int j = 0; j < 3; j++) {
            if (board[0][j] == currentPlayer && board[1][j] == currentPlayer && board[2][j] == currentPlayer) {
                return true;
            }
        }

        if (board[0][0] == currentPlayer && board[1][1] == currentPlayer && board[2][2] == currentPlayer) {
            return true;
        }

        if (board[0][2] == currentPlayer && board[1][1] == currentPlayer && board[2][0] == currentPlayer) {
            return true;
        }

        return false;
    }

    static boolean checkDraw() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == ' ') {
                    return false;
                }
            }
        }
        return true;
    }
}
