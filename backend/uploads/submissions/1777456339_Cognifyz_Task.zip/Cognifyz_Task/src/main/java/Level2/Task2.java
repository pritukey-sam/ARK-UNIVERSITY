package Level2;

import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Password Strength Checker ===");
        System.out.println();

        System.out.print("Enter your password: ");
        String password = sc.nextLine();

        int score = 0;
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        int length = password.length();

        for (int i = 0; i < length; i++) {
            char ch = password.charAt(i);

            if (ch >= 'A' && ch <= 'Z') {
                hasUppercase = true;
            } else if (ch >= 'a' && ch <= 'z') {
                hasLowercase = true;
            } else if (ch >= '0' && ch <= '9') {
                hasNumber = true;
            } else {
                hasSpecial = true;
            }
        }

        if (length >= 8) {
            score++;
        }
        if (length >= 12) {
            score++;
        }
        if (hasUppercase) {
            score++;
        }
        if (hasLowercase) {
            score++;
        }
        if (hasNumber) {
            score++;
        }
        if (hasSpecial) {
            score++;
        }

        System.out.println();
        System.out.println("--- Password Analysis ---");
        System.out.println("Password length: " + length + " characters");
        System.out.println();

        System.out.println("Criteria Check:");
        System.out.println("✓ Length >= 8 characters: " + (length >= 8 ? "Yes" : "No"));
        System.out.println("✓ Length >= 12 characters: " + (length >= 12 ? "Yes" : "No"));
        System.out.println("✓ Contains uppercase letters: " + (hasUppercase ? "Yes" : "No"));
        System.out.println("✓ Contains lowercase letters: " + (hasLowercase ? "Yes" : "No"));
        System.out.println("✓ Contains numbers: " + (hasNumber ? "Yes" : "No"));
        System.out.println("✓ Contains special characters: " + (hasSpecial ? "Yes" : "No"));
        System.out.println();

        System.out.println("Strength Score: " + score + "/6");
        System.out.println();

        String strength = "";
        String feedback = "";

        if (score <= 2) {
            strength = "WEAK";
            feedback = "Your password is weak. Consider making it longer and adding different character types.";
        } else if (score <= 4) {
            strength = "MODERATE";
            feedback = "Your password is moderate. Add more character variety for better security.";
        } else if (score == 5) {
            strength = "STRONG";
            feedback = "Your password is strong! Consider adding more characters for maximum security.";
        } else {
            strength = "VERY STRONG";
            feedback = "Excellent! Your password is very strong and secure.";
        }

        System.out.println("Password Strength: " + strength);
        System.out.println(feedback);
        System.out.println();

        if (!hasUppercase) {
            System.out.println("Suggestion: Add uppercase letters (A-Z)");
        }
        if (!hasLowercase) {
            System.out.println("Suggestion: Add lowercase letters (a-z)");
        }
        if (!hasNumber) {
            System.out.println("Suggestion: Add numbers (0-9)");
        }
        if (!hasSpecial) {
            System.out.println("Suggestion: Add special characters (!@#$%^&*)");
        }
        if (length < 8) {
            System.out.println("Suggestion: Make password at least 8 characters long");
        } else if (length < 12) {
            System.out.println("Suggestion: Make password at least 12 characters for better security");
        }

        sc.close();
    }
}
