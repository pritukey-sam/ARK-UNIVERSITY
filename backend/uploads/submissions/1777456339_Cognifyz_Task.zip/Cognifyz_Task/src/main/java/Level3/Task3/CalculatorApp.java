//package Level3.Task3;
//
//import javafx.application.Application;
//import javafx.geometry.Insets;
//import javafx.geometry.Pos;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.control.TextField;
//import javafx.scene.layout.GridPane;
//import javafx.scene.layout.VBox;
//import javafx.stage.Stage;
//
//public class CalculatorApp extends Application {
//
//    private TextField display;
//    private String operator = "";
//    private double firstNumber = 0;
//    private boolean startNewNumber = true;
//
//    public static void main(String[] args) {
//        launch(args);
//    }
//
//    @Override
//    public void start(Stage primaryStage) {
//        primaryStage.setTitle("Calculator");
//
//        display = new TextField("0");
//        display.setEditable(false);
//        display.setAlignment(Pos.CENTER_RIGHT);
//        display.setStyle("-fx-font-size: 24px; -fx-background-color: #f0f0f0;");
//        display.setPrefHeight(60);
//
//        GridPane buttonPanel = createButtonPanel();
//
//        VBox root = new VBox(10);
//        root.setPadding(new Insets(10));
//        root.getChildren().addAll(display, buttonPanel);
//
//        Scene scene = new Scene(root, 300, 400);
//        primaryStage.setScene(scene);
//        primaryStage.setResizable(false);
//        primaryStage.show();
//    }
//
//    private GridPane createButtonPanel() {
//        GridPane grid = new GridPane();
//        grid.setHgap(5);
//        grid.setVgap(5);
//        grid.setAlignment(Pos.CENTER);
//
//        String[][] buttons = {
//                {"7", "8", "9", "/"},
//                {"4", "5", "6", "*"},
//                {"1", "2", "3", "-"},
//                {"C", "0", "=", "+"}
//        };
//
//        for (int row = 0; row < buttons.length; row++) {
//            for (int col = 0; col < buttons[row].length; col++) {
//                String buttonText = buttons[row][col];
//                Button button = createButton(buttonText);
//                grid.add(button, col, row);
//            }
//        }
//
//        return grid;
//    }
//
//    private Button createButton(String text) {
//        Button button = new Button(text);
//        button.setPrefSize(60, 60);
//        button.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
//
//        if (text.matches("[0-9]")) {
//            button.setStyle("-fx-font-size: 18px; -fx-background-color: #e0e0e0;");
//            button.setOnAction(e -> handleNumber(text));
//        } else if (text.equals("C")) {
//            button.setStyle("-fx-font-size: 18px; -fx-background-color: #ff6b6b;");
//            button.setOnAction(e -> handleClear());
//        } else if (text.equals("=")) {
//            button.setStyle("-fx-font-size: 18px; -fx-background-color: #4ecdc4;");
//            button.setOnAction(e -> handleEquals());
//        } else {
//            button.setStyle("-fx-font-size: 18px; -fx-background-color: #95e1d3;");
//            button.setOnAction(e -> handleOperator(text));
//        }
//
//        return button;
//    }
//
//    private void handleNumber(String number) {
//        if (startNewNumber) {
//            display.setText(number);
//            startNewNumber = false;
//        } else {
//            display.setText(display.getText() + number);
//        }
//    }
//
//    private void handleOperator(String op) {
//        firstNumber = Double.parseDouble(display.getText());
//        operator = op;
//        startNewNumber = true;
//    }
//
//    private void handleEquals() {
//        double secondNumber = Double.parseDouble(display.getText());
//        double result = 0;
//
//        switch (operator) {
//            case "+":
//                result = firstNumber + secondNumber;
//                break;
//            case "-":
//                result = firstNumber - secondNumber;
//                break;
//            case "*":
//                result = firstNumber * secondNumber;
//                break;
//            case "/":
//                if (secondNumber != 0) {
//                    result = firstNumber / secondNumber;
//                } else {
//                    display.setText("Error");
//                    return;
//                }
//                break;
//        }
//
//        display.setText(String.valueOf(result));
//        startNewNumber = true;
//    }
//
//    private void handleClear() {
//        display.setText("0");
//        firstNumber = 0;
//        operator = "";
//        startNewNumber = true;
//    }
//}
