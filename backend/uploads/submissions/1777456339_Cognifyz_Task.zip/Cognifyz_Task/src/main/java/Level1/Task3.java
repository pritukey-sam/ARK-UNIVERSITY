package Level1;

import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Student Grade Calculator ===");
        System.out.println();

        System.out.print("Enter the number of grades: ");
        int numGrades = sc.nextInt();

        double[] grades = new double[numGrades];
        double sum = 0;

        System.out.println();
        for (int i = 0; i < numGrades; i++) {
            System.out.print("Enter grade " + (i + 1) + ": ");
            grades[i] = sc.nextDouble();
            sum += grades[i];
        }

        double average = sum / numGrades;

        System.out.println();
        System.out.println("--- Grade Summary ---");
        System.out.println("Total Grades Entered: " + numGrades);
        System.out.println("Sum of Grades: " + sum);
        System.out.printf("Average Grade: %.2f%n", average);

        System.out.println();
        if (average >= 90) {
            System.out.println("Grade: A (Excellent)");
        } else if (average >= 80) {
            System.out.println("Grade: B (Good)");
        } else if (average >= 70) {
            System.out.println("Grade: C (Average)");
        } else if (average >= 60) {
            System.out.println("Grade: D (Below Average)");
        } else {
            System.out.println("Grade: F (Fail)");
        }

        sc.close();
    }
}
