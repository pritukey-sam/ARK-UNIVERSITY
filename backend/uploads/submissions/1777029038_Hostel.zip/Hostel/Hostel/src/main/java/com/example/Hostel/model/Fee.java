package com.example.Hostel.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "fees")
public class Fee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Student ke saath relation
    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    @NotNull(message = "Amount required hai")
    private Double amount;

    // Fee month: "January 2025", "February 2025"
    private String month;

    // Status: Paid, Pending
    private String status = "Pending";

    // Jab fee pay ki gayi
    private LocalDate paidDate;

    // Due date
    private LocalDate dueDate;

    // Fee type: Hostel Fee, Mess Fee, etc.
    private String feeType = "Hostel Fee";

    // ============ Constructors ============
    public Fee() {}

    public Fee(Student student, Double amount, String month,
               String status, LocalDate dueDate, String feeType) {
        this.student  = student;
        this.amount   = amount;
        this.month    = month;
        this.status   = status;
        this.dueDate  = dueDate;
        this.feeType  = feeType;
    }

    // ============ Getters & Setters ============
    public Long getId()              { return id; }
    public void setId(Long id)       { this.id = id; }

    public Student getStudent()              { return student; }
    public void setStudent(Student student) { this.student = student; }

    public Double getAmount()                { return amount; }
    public void setAmount(Double amount)     { this.amount = amount; }

    public String getMonth()             { return month; }
    public void setMonth(String month)   { this.month = month; }

    public String getStatus()                { return status; }
    public void setStatus(String status)     { this.status = status; }

    public LocalDate getPaidDate()               { return paidDate; }
    public void setPaidDate(LocalDate paidDate) { this.paidDate = paidDate; }

    public LocalDate getDueDate()                { return dueDate; }
    public void setDueDate(LocalDate dueDate)    { this.dueDate = dueDate; }

    public String getFeeType()               { return feeType; }
    public void setFeeType(String feeType)   { this.feeType = feeType; }
}