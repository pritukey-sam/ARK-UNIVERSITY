package com.example.Hostel.config;

public class SecurityConfig {
}
