package com.example.Hostel.service;

import com.example.Hostel.model.Fee;
import com.example.Hostel.model.Student;
import com.example.Hostel.repository.FeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class FeeService {

    @Autowired
    private FeeRepository feeRepository;

    // Sabhi fees lao
    public List<Fee> getAllFees() {
        return feeRepository.findAll();
    }

    // ID se fee dhundo
    public Fee getFeeById(Long id) {
        return feeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Fee record nahi mila ID: " + id));
    }

    // Fee save karo
    public Fee saveFee(Fee fee) {
        return feeRepository.save(fee);
    }

    // Fee delete karo
    public void deleteFee(Long id) {
        feeRepository.deleteById(id);
    }

    // Fee ko Paid mark karo
    public void markAsPaid(Long id) {
        Fee fee = getFeeById(id);
        fee.setStatus("Paid");
        fee.setPaidDate(LocalDate.now()); // Aaj ki date set karo
        feeRepository.save(fee);
    }

    // Ek student ki saari fees
    public List<Fee> getFeesByStudent(Student student) {
        return feeRepository.findByStudent(student);
    }

    // Status se fees lao
    public List<Fee> getFeesByStatus(String status) {
        return feeRepository.findByStatus(status);
    }

    // Dashboard ke liye pending fees count
    public long getPendingCount() {
        return feeRepository.countByStatus("Pending");
    }

    // Month se fees lao
    public List<Fee> getFeesByMonth(String month) {
        return feeRepository.findByMonth(month);
    }
}