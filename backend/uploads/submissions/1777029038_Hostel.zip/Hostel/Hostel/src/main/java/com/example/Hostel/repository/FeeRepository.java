package com.example.Hostel.repository;

import com.example.Hostel.model.Fee;
import com.example.Hostel.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FeeRepository extends JpaRepository<Fee, Long> {

    // Ek student ki saari fees
    List<Fee> findByStudent(Student student);

    // Status se fees dhundo (Paid / Pending)
    List<Fee> findByStatus(String status);

    // Student aur status dono se dhundo
    List<Fee> findByStudentAndStatus(Student student, String status);

    // Month se fees dhundo
    List<Fee> findByMonth(String month);

    // Pending fees ki count - dashboard ke liye
    long countByStatus(String status);
}