package com.example.Hostel.controller;

import com.example.Hostel.model.Student;
import com.example.Hostel.service.RoomService;
import com.example.Hostel.service.StudentService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private RoomService roomService;

    // GET - Sabhi students ki list
    @GetMapping
    public String listStudents(HttpSession session, Model model) {
        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("students", studentService.getAllStudents());
        return "students"; // students.html
    }

    // GET - Add student form dikhao
    @GetMapping("/add")
    public String showAddForm(HttpSession session, Model model) {
        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("student", new Student());
        model.addAttribute("rooms", roomService.getAvailableRooms());
        return "add-student"; // add-student.html
    }

    // POST - Student save karo
    @PostMapping("/save")
    public String saveStudent(
            @ModelAttribute Student student,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        studentService.saveStudent(student);
        return "redirect:/students";
    }

    // GET - Student delete karo
    @GetMapping("/delete/{id}")
    public String deleteStudent(
            @PathVariable Long id,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        studentService.deleteStudent(id);
        return "redirect:/students";
    }

    // GET - Edit form dikhao
    @GetMapping("/edit/{id}")
    public String showEditForm(
            @PathVariable Long id,
            HttpSession session,
            Model model) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("student", studentService.getStudentById(id));
        model.addAttribute("rooms", roomService.getAvailableRooms());
        return "add-student"; // same form reuse
    }
}