package com.example.Hostel.controller;

import com.example.Hostel.model.Room;
import com.example.Hostel.service.RoomService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/rooms")
public class RoomController {

    @Autowired
    private RoomService roomService;

    // GET - Sabhi rooms ki list
    @GetMapping
    public String listRooms(HttpSession session, Model model) {
        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("rooms", roomService.getAllRooms());
        return "rooms"; // rooms.html
    }

    // GET - Add room form
    @GetMapping("/add")
    public String showAddForm(HttpSession session, Model model) {
        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("room", new Room());
        return "add-room"; // add-room.html
    }

    // POST - Room save karo
    @PostMapping("/save")
    public String saveRoom(
            @ModelAttribute Room room,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        roomService.saveRoom(room);
        return "redirect:/rooms";
    }

    // GET - Room delete
    @GetMapping("/delete/{id}")
    public String deleteRoom(
            @PathVariable Long id,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        roomService.deleteRoom(id);
        return "redirect:/rooms";
    }

    // GET - Edit room
    @GetMapping("/edit/{id}")
    public String showEditForm(
            @PathVariable Long id,
            HttpSession session,
            Model model) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("room", roomService.getRoomById(id));
        return "add-room";
    }
}