package com.example.Hostel.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "rooms")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Room number required hai")
    @Column(unique = true)
    private String roomNumber;

    @NotNull(message = "Capacity required hai")
    private Integer capacity; // Max kitne students

    // Room type: Single, Double, Triple
    private String roomType;

    // Status: Available, Occupied, Maintenance
    private String status = "Available";

    private String floor; // Ground, 1st, 2nd...

    // ============ Constructors ============
    public Room() {}

    public Room(String roomNumber, Integer capacity,
                String roomType, String status, String floor) {
        this.roomNumber = roomNumber;
        this.capacity   = capacity;
        this.roomType   = roomType;
        this.status     = status;
        this.floor      = floor;
    }

    // ============ Getters & Setters ============
    public Long getId()                  { return id; }
    public void setId(Long id)           { this.id = id; }

    public String getRoomNumber()                    { return roomNumber; }
    public void setRoomNumber(String roomNumber)     { this.roomNumber = roomNumber; }

    public Integer getCapacity()                 { return capacity; }
    public void setCapacity(Integer capacity)    { this.capacity = capacity; }

    public String getRoomType()                  { return roomType; }
    public void setRoomType(String roomType)     { this.roomType = roomType; }

    public String getStatus()                { return status; }
    public void setStatus(String status)     { this.status = status; }

    public String getFloor()             { return floor; }
    public void setFloor(String floor)   { this.floor = floor; }
}