package com.example.Hostel.controller;

import com.example.Hostel.model.Fee;
import com.example.Hostel.service.FeeService;
import com.example.Hostel.service.StudentService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/fees")
public class FeeController {

    @Autowired
    private FeeService feeService;

    @Autowired
    private StudentService studentService;

    // GET - Fees list
    @GetMapping
    public String listFees(HttpSession session, Model model) {
        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("fees", feeService.getAllFees());
        return "fees"; // fees.html
    }

    // GET - Add fee form
    @GetMapping("/add")
    public String showAddForm(HttpSession session, Model model) {
        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("fee", new Fee());
        model.addAttribute("students", studentService.getAllStudents());
        return "add-fee"; // add-fee.html
    }

    // POST - Fee save karo
    @PostMapping("/save")
    public String saveFee(
            @ModelAttribute Fee fee,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        feeService.saveFee(fee);
        return "redirect:/fees";
    }

    // GET - Fee status update (Paid/Pending toggle)
    @GetMapping("/markPaid/{id}")
    public String markAsPaid(
            @PathVariable Long id,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        feeService.markAsPaid(id);
        return "redirect:/fees";
    }

    // GET - Delete fee
    @GetMapping("/delete/{id}")
    public String deleteFee(
            @PathVariable Long id,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        feeService.deleteFee(id);
        return "redirect:/fees";
    }
}