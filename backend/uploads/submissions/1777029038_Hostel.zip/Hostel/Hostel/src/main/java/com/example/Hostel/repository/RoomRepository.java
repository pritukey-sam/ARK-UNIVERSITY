package com.example.Hostel.repository;

import com.example.Hostel.model.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {

    // Available rooms dhundo
    List<Room> findByStatus(String status);

    // Room number se room dhundo
    Room findByRoomNumber(String roomNumber);

    // Floor se rooms dhundo
    List<Room> findByFloor(String floor);

    // Room type se dhundo (Single, Double, Triple)
    List<Room> findByRoomType(String roomType);

    // Available rooms ki count - dashboard ke liye
    long countByStatus(String status);
}