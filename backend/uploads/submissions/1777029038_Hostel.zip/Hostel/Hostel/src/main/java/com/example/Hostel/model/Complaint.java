package com.example.Hostel.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDate;

@Entity
@Table(name = "complaints")
public class Complaint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Student ka complaint
    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    @NotBlank(message = "Title required hai")
    private String title;

    @NotBlank(message = "Description required hai")
    @Column(length = 1000)
    private String description;

    // Status: Open, Resolved
    private String status = "Open";

    // Complaint category: Maintenance, Food, Cleanliness, Other
    private String category;

    // Jab complaint submit ki
    private LocalDate complaintDate = LocalDate.now();

    // Jab resolve hui
    private LocalDate resolvedDate;

    // ============ Constructors ============
    public Complaint() {}

    public Complaint(Student student, String title,
                     String description, String category) {
        this.student       = student;
        this.title         = title;
        this.description   = description;
        this.category      = category;
        this.complaintDate = LocalDate.now();
        this.status        = "Open";
    }

    // ============ Getters & Setters ============
    public Long getId()              { return id; }
    public void setId(Long id)       { this.id = id; }

    public Student getStudent()              { return student; }
    public void setStudent(Student student) { this.student = student; }

    public String getTitle()             { return title; }
    public void setTitle(String title)   { this.title = title; }

    public String getDescription()                   { return description; }
    public void setDescription(String description)   { this.description = description; }

    public String getStatus()                { return status; }
    public void setStatus(String status)     { this.status = status; }

    public String getCategory()                  { return category; }
    public void setCategory(String category)     { this.category = category; }

    public LocalDate getComplaintDate()                      { return complaintDate; }
    public void setComplaintDate(LocalDate complaintDate)    { this.complaintDate = complaintDate; }

    public LocalDate getResolvedDate()                   { return resolvedDate; }
    public void setResolvedDate(LocalDate resolvedDate)  { this.resolvedDate = resolvedDate; }
}