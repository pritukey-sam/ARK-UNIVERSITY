package com.example.Hostel.service;

import com.example.Hostel.model.Room;
import com.example.Hostel.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    // Sabhi rooms lao
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    // ID se room dhundo
    public Room getRoomById(Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Room nahi mili ID: " + id));
    }

    // Room save karo
    public Room saveRoom(Room room) {
        return roomRepository.save(room);
    }

    // Room delete karo
    public void deleteRoom(Long id) {
        roomRepository.deleteById(id);
    }

    // Sirf available rooms lao (Add Student form ke liye)
    public List<Room> getAvailableRooms() {
        return roomRepository.findByStatus("Available");
    }

    // Dashboard ke liye total rooms count
    public long getTotalCount() {
        return roomRepository.count();
    }

    // Dashboard ke liye available rooms count
    public long getAvailableCount() {
        return roomRepository.countByStatus("Available");
    }

    // Room ka status update karo
    public void updateRoomStatus(String roomNumber, String status) {
        Room room = roomRepository.findByRoomNumber(roomNumber);
        if (room != null) {
            room.setStatus(status);
            roomRepository.save(room);
        }
    }
}