package com.example.Hostel.controller;

import com.example.Hostel.model.Complaint;
import com.example.Hostel.service.ComplaintService;
import com.example.Hostel.service.StudentService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/complaints")
public class ComplaintController {

    @Autowired
    private ComplaintService complaintService;

    @Autowired
    private StudentService studentService;

    // GET - Complaints list
    @GetMapping
    public String listComplaints(HttpSession session, Model model) {
        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("complaints", complaintService.getAllComplaints());
        return "complaints"; // complaints.html
    }

    // GET - Add complaint form
    @GetMapping("/add")
    public String showAddForm(HttpSession session, Model model) {
        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        model.addAttribute("complaint", new Complaint());
        model.addAttribute("students", studentService.getAllStudents());
        return "add-complaint"; // add-complaint.html
    }

    // POST - Complaint save karo
    @PostMapping("/save")
    public String saveComplaint(
            @ModelAttribute Complaint complaint,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        complaintService.saveComplaint(complaint);
        return "redirect:/complaints";
    }

    // GET - Complaint resolve karo
    @GetMapping("/resolve/{id}")
    public String resolveComplaint(
            @PathVariable Long id,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        complaintService.resolveComplaint(id);
        return "redirect:/complaints";
    }

    // GET - Delete complaint
    @GetMapping("/delete/{id}")
    public String deleteComplaint(
            @PathVariable Long id,
            HttpSession session) {

        if (session.getAttribute("loggedInAdmin") == null)
            return "redirect:/login";

        complaintService.deleteComplaint(id);
        return "redirect:/complaints";
    }
}