package com.example.Hostel.repository;

import com.example.Hostel.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    List<Student> findByNameContainingIgnoreCase(String name);


    List<Student> findByRoomNumber(String roomNumber);


    List<Student> findByCourse(String course);


    List<Student> findByYear(Integer year);


    long count();
}