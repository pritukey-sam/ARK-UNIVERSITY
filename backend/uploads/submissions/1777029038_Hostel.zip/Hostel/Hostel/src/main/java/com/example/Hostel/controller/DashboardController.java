package com.example.Hostel.controller;



import com.example.Hostel.service.ComplaintService;
import com.example.Hostel.service.FeeService;
import com.example.Hostel.service.RoomService;
import com.example.Hostel.service.StudentService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private RoomService roomService;

    @Autowired
    private FeeService feeService;

    @Autowired
    private ComplaintService complaintService;

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {

        // Session check - agar login nahi hai toh login page par bhejo
        if (session.getAttribute("loggedInAdmin") == null) {
            return "redirect:/login";
        }

        // Dashboard ke liye counts fetch karo
        model.addAttribute("totalStudents", studentService.getTotalCount());
        model.addAttribute("totalRooms",    roomService.getTotalCount());
        model.addAttribute("availableRooms", roomService.getAvailableCount());
        model.addAttribute("pendingFees",   feeService.getPendingCount());
        model.addAttribute("openComplaints", complaintService.getOpenCount());
        model.addAttribute("adminName", session.getAttribute("loggedInAdmin"));

        return "dashboard"; // dashboard.html
    }
}
