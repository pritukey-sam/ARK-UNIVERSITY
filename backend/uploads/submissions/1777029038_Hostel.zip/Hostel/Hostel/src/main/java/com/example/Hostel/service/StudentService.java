package com.example.Hostel.service;

import com.example.Hostel.model.Student;
import com.example.Hostel.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    // Sabhi students lao
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    // ID se student dhundo
    public Student getStudentById(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student nahi mila ID: " + id));
    }

    // Student save karo (Add + Edit dono)
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    // Student delete karo
    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }

    // Name se search karo
    public List<Student> searchByName(String name) {
        return studentRepository.findByNameContainingIgnoreCase(name);
    }

    // Room number se students dhundo
    public List<Student> getStudentsByRoom(String roomNumber) {
        return studentRepository.findByRoomNumber(roomNumber);
    }

    // Dashboard ke liye total count
    public long getTotalCount() {
        return studentRepository.count();
    }
}