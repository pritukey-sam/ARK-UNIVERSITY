package com.example.Hostel.service;

import com.example.Hostel.model.Complaint;
import com.example.Hostel.repository.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class ComplaintService {

    @Autowired
    private ComplaintRepository complaintRepository;

    // Sabhi complaints lao
    public List<Complaint> getAllComplaints() {
        return complaintRepository.findAll();
    }

    // ID se complaint dhundo
    public Complaint getComplaintById(Long id) {
        return complaintRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Complaint nahi mili ID: " + id));
    }

    // Complaint save karo
    public Complaint saveComplaint(Complaint complaint) {
        return complaintRepository.save(complaint);
    }

    // Complaint delete karo
    public void deleteComplaint(Long id) {
        complaintRepository.deleteById(id);
    }

    // Complaint resolve karo
    public void resolveComplaint(Long id) {
        Complaint complaint = getComplaintById(id);
        complaint.setStatus("Resolved");
        complaint.setResolvedDate(LocalDate.now()); // Aaj ki date
        complaintRepository.save(complaint);
    }

    // Status se complaints lao
    public List<Complaint> getComplaintsByStatus(String status) {
        return complaintRepository.findByStatus(status);
    }

    // Dashboard ke liye open complaints count
    public long getOpenCount() {
        return complaintRepository.countByStatus("Open");
    }

    // Category se complaints lao
    public List<Complaint> getComplaintsByCategory(String category) {
        return complaintRepository.findByCategory(category);
    }
}