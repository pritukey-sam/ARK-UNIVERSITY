package com.example.Hostel.repository;

import com.example.Hostel.model.Complaint;
import com.example.Hostel.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Long> {

    // Ek student ki saari complaints
    List<Complaint> findByStudent(Student student);

    // Status se complaints dhundo (Open / Resolved)
    List<Complaint> findByStatus(String status);

    // Category se dhundo (Maintenance, Food, etc.)
    List<Complaint> findByCategory(String category);

    // Open complaints ki count - dashboard ke liye
    long countByStatus(String status);
}