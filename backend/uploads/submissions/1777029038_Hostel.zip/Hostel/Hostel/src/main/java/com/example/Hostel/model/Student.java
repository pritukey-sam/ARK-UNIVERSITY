package com.example.Hostel.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Name required hai")
    private String name;

    @NotBlank(message = "Email required hai")
    @Email(message = "Valid email do")
    private String email;

    @NotBlank(message = "Phone required hai")
    private String phone;

    @NotBlank(message = "Course required hai")
    private String course;

    private String address;

    // Room number manually store karenge (simple approach)
    private String roomNumber;

    @NotNull(message = "Year required hai")
    private Integer year; // 1st, 2nd, 3rd year

    // ============ Constructors ============
    public Student() {}

    public Student(String name, String email, String phone,
                   String course, String address,
                   String roomNumber, Integer year) {
        this.name       = name;
        this.email      = email;
        this.phone      = phone;
        this.course     = course;
        this.address    = address;
        this.roomNumber = roomNumber;
        this.year       = year;
    }

    // ============ Getters & Setters ============
    public Long getId()                  { return id; }
    public void setId(Long id)           { this.id = id; }

    public String getName()              { return name; }
    public void setName(String name)     { this.name = name; }

    public String getEmail()             { return email; }
    public void setEmail(String email)   { this.email = email; }

    public String getPhone()             { return phone; }
    public void setPhone(String phone)   { this.phone = phone; }

    public String getCourse()            { return course; }
    public void setCourse(String course) { this.course = course; }

    public String getAddress()               { return address; }
    public void setAddress(String address)   { this.address = address; }

    public String getRoomNumber()                    { return roomNumber; }
    public void setRoomNumber(String roomNumber)     { this.roomNumber = roomNumber; }

    public Integer getYear()             { return year; }
    public void setYear(Integer year)    { this.year = year; }
}