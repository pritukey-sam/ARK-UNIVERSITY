// =====================================
// Professional Dashboard JS
// =====================================

document.addEventListener('DOMContentLoaded', function() {

    // 1. Display Current Date
    displayCurrentDate();

    // 2. Initialize Charts
    initOccupancyChart();
    initRoomStatusChart();

    // 3. Animate Numbers
    animateStatNumbers();

    // 4. Add hover effects
    addCardHoverEffects();
});

// =====================================
// Display Current Date
// =====================================
function displayCurrentDate() {
    const dateElement = document.getElementById('currentDate');
    if (!dateElement) return;

    const options = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    };
    const today = new Date();
    dateElement.textContent = today.toLocaleDateString('en-US', options);
}

// =====================================
// Occupancy Chart (Line Chart)
// =====================================
function initOccupancyChart() {
    const ctx = document.getElementById('occupancyChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
            datasets: [{
                label: 'Occupancy Rate (%)',
                data: [65, 72, 78, 85, 82, 88, 85],
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointRadius: 5,
                pointHoverRadius: 7,
                pointBackgroundColor: '#667eea',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#2c3e50',
                    padding: 12,
                    cornerRadius: 8,
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    displayColors: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: {
                        color: '#f1f3f5'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

// =====================================
// Room Status Chart (Doughnut Chart)
// =====================================
function initRoomStatusChart() {
    const ctx = document.getElementById('roomStatusChart');
    if (!ctx) return;

    // Get values from page (Thymeleaf se aayenge)
    const available = parseInt(ctx.dataset.available || 2);
    const occupied = parseInt(ctx.dataset.occupied || 0);

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Available', 'Occupied'],
            datasets: [{
                data: [available, occupied],
                backgroundColor: [
                    '#11998e',
                    '#dc3545'
                ],
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            cutout: '70%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#2c3e50',
                    padding: 12,
                    cornerRadius: 8
                }
            }
        }
    });
}

// =====================================
// Animate Stat Numbers
// =====================================
function animateStatNumbers() {
    const statValues = document.querySelectorAll('.stat-value');

    statValues.forEach(stat => {
        const finalValue = parseInt(stat.textContent);
        let currentValue = 0;
        const increment = finalValue / 50;
        const duration = 1000;
        const stepTime = duration / 50;

        const counter = setInterval(() => {
            currentValue += increment;
            if (currentValue >= finalValue) {
                stat.textContent = finalValue;
                clearInterval(counter);
            } else {
                stat.textContent = Math.floor(currentValue);
            }
        }, stepTime);
    });
}

// =====================================
// Card Hover Effects
// =====================================
function addCardHoverEffects() {
    const cards = document.querySelectorAll('.stat-card, .chart-card, .info-card');

    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transition = 'all 0.3s ease';
        });
    });
}

// =====================================
// Progress Bar Animation
// =====================================
function animateProgressBars() {
    const progressBars = document.querySelectorAll('.progress-bar');

    progressBars.forEach(bar => {
        const width = bar.style.width;
        bar.style.width = '0';
        setTimeout(() => {
            bar.style.width = width;
        }, 200);
    });
}

// Call on load
animateProgressBars();